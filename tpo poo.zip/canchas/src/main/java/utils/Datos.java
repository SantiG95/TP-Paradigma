/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utils;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Set;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author ehoka
 */
public class Datos extends JPanel{
    
    public Set<Date> fechasOcupadas;
    public javax.swing.JPanel jPanel1; 
    private static int IdEvento = 0; 
    
    public void guardarDatos(String organizador, Date fecha, String tamañoSeleccionado, ArrayList<String> invitados, String Horario) {
        IdEvento++;
        String fechaFormateada = new SimpleDateFormat("dd/MM/yyyy").format(fecha);
        
        String stringinvitados = "";
        for (String inv : invitados){
            stringinvitados = stringinvitados + inv + " " ;
        }
        
        // Crear la cadena con el formato deseado
        String datos = organizador + "," + fechaFormateada + "," + Horario +","+ tamañoSeleccionado+ "," + stringinvitados + "," + IdEvento;

        try (BufferedWriter writer = new BufferedWriter(new FileWriter("rtas.txt", true))) { // 'true' para agregar al final
            writer.write(datos + "\n");  // Escribir en una línea y agregar un salto de línea al final
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    

    public void modificarDatos(String organizador, Date fecha, String tamañoSeleccionado, String invitados, String Horario, String IdEvento) {
        
        String fechaFormateada = new SimpleDateFormat("dd/MM/yyyy").format(fecha);
        String nuevosDatos = organizador + "," + fechaFormateada + "," + Horario + "," + tamañoSeleccionado + "," + invitados + "," + IdEvento;
        
        List<String> lineas = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader("rtas.txt"))) {
            String linea;

            while ((linea = reader.readLine()) != null) {
                String[] datos = linea.split(","); // Divide la línea en partes
                if (datos.length > 5 && datos[5].equals(IdEvento)) {
                    // Si el ID coincide, reemplazamos la línea con los nuevos datos
                    lineas.add(nuevosDatos);
                } else {
                    // Si no, mantenemos la línea original
                    lineas.add(linea);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            return; // Salimos si hay un error de lectura
        }

        // Reescribimos el archivo con los datos actualizados
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("rtas.txt"))) {
            for (String linea : lineas) {
                writer.write(linea);
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
    


