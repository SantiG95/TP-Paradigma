package logica;

import logica.Clases.AlquilerCancha;
import igu.Pantalla;
import logica.Clases.ListaEventos;


public class PruebaCapas {
    
    
    public static void main(String[] args) {
        
       Pantalla panta = new Pantalla();
       panta.setVisible(true);
       panta.setLocationRelativeTo(null);
        
       ListaEventos listita = new ListaEventos();
       listita.agregarEvento(eventoParaAgregar, fecha);
       
    }
}
